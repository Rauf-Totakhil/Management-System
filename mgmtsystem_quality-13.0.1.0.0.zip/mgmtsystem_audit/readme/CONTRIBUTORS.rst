* Daniel Reis <dreis.pt@hotmail.com>
* Joao Alfredo Gama Batista <joao.gama@savoirfairelinux.com>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* Sandy Carter <sandy.carter@savoirfairelinux.com>
* Virgil Dupras <virgil.dupras@savoirfairelinux.com>
* Loïc lacroix <loic.lacroix@savoirfairelinux.com>
* Gervais Naoussi <gervaisnaoussi@gmail.com>
* Luk Vermeylen <luk@allmas-it.be>
* Maxime Chambreuil <mchambreuil@ursainfosystems.com>
* Eugen Don <eugen.don@don-systems.de>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda

* `Guadaltech <https://www.guadaltech.es>`_:

  * Fernando La Chica
