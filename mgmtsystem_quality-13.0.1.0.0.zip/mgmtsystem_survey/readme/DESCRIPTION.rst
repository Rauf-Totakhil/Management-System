This module enables you to manage your customer satisfaction surveys and their answers.
