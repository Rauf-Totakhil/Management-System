To enter your quality manual, you need to:

* go to Management Systems > Documentation > Manuals
* Create a new page and select the Quality Manual category.
