* Images support in the documentation
* Key Performance Indicators
* Employee Training
* Equipment Management
