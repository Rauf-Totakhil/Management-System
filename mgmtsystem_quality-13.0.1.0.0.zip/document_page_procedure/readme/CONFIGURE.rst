To be able configure your template of procedures, you need to install
mgmtsystem_manual:

* go to Management Systems > Configuration > Categories
* select the Procedure category
* customize the template
