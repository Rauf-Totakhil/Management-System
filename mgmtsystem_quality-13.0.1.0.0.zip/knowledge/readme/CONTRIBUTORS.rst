* Odoo SA <info@odoo.com>
* Savoir-faire Linux <support@savoirfairelinux.com>
* Gervais Naoussi <gervaisnaoussi@gmail.com>
* Leonardo Donelli <leonardo.donelli@monksoftware.it>
* Maxime Chambreuil <mchambreuil@ursainfosystems.com>
* Fayez Qandeel
* Iván Todorovich <ivan.todorovich@gmail.com>
* Jordi Ballester <jordi.ballester@forgeflow.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Vicent Cubells
  * Ernesto Tejeda
