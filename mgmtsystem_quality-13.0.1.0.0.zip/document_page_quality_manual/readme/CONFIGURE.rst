
To enter your work instruction template, you need to:

* go to Management Systems > Configuration > Categories
* select the Work Instructions category and edit the template
