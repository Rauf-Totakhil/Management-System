import messages
import  functions 

print("\n\n\n")
print(messages.welcome)
print("\n")

functions.start_program()