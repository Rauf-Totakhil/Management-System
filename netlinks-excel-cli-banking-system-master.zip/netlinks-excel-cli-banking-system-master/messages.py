welcome = """Welcome To Banking System""".center(120, "-")
open_account = """Add User Data To Create An Account""".center(100, "-")
account_success = """Account Created Seccessfully""".center(130, "-")
id_not_unique = """\n WARNING: Id Already Exists in database"""
email_not_unique = """\n WARNING: Email Already Exists in database"""
account_credentials = """Enter Your Account Credentials""".center(100, "-")
invalid_credentials = """\n Warning: Invalid Id Or Password"""
not_enough_balance = """Warning: You Don't have enouht balance """
withdraw_deposit_success = ("""{}  Seccessfully Availible balance is {}"""
                            .center(130, "-"))
check_balance = """Check Balance""".center(130, "-")
balance_result = """Your Balance is: {}"""
delete_account = """Delete User Account""".center(130, "-")
id_not_found = """\n WARNING: Id Does Not Exists in database"""
account_deleted_success = """Account Deleted Seccessfully""".center(130, "-")