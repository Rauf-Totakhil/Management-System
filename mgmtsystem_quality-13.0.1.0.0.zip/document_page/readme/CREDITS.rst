The development of this module has been financially supported by:

* Odoo SA <http://www.odoo.com>
* Savoir-faire Linux <http://www.savoirfairelinux.com>
