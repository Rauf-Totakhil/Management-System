This module was written to allow you to manage your Quality Management System (QMS)
within Odoo. It provides applications to manage:

* Quality Manual
* Procedures and Work Instructions
* Top Management Reviews
* Audits
* Nonconformities (NC)
* Immediate/Corrective/Preventive Actions
* Improvement Opportunities
* Satisfaction Survey

For further information, please visit:

* http://www.slideshare.net/max3903/iso-anmanagement-systemswithopenerpena
* http://www.slideshare.net/max3903/openerp-management-system-modules
