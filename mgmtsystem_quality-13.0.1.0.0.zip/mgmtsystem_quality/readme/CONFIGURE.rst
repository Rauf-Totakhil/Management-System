To configure this module, you need to:

* Add users to the Management System groups (Manager, Auditor, NC Approver)
* Import your documentation (manuals and procedures)
* Review the data provided (i.e. NC origins and causes)
* Customize the Customer Satisfaction survey
* Customize email templates for reminders
* Import your legacy data (NC, actions)
