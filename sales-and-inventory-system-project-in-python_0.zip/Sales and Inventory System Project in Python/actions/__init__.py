from .register_sale import *
from .register_product_arrival import *
from .query_inventory_data import*
from .most_sold_items import*
from .employees_with_most_sales import *
