To configure this module, you need to:

#. Go to Management System > Configuration > Surveys
#. Click on Create to create your customer satisfaction survey
#. Add pages and questions
