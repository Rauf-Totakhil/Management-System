This module provides a Procedure Template. If mgmtsystem_manual will be
installed you can change initial template.
